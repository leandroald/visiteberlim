---
title: "Sobre a Maria Helena"
---

Sou **Maria Helena**, brasileira apaixonada por história e cultura.  
Moro em Berlim desde 2003 e desde então ajudo brasileiros a conhecerem essa cidade fascinante com uma visão acolhedora e cheia de contexto histórico.

Ofereço tours sob medida para todas as idades, estilos e curiosidades. Vamos juntos explorar Berlim!
