---
title: "Tours Disponíveis"
---

Ofereço os seguintes passeios:

- **Berlim Clássica** – Portão de Brandemburgo, Muro de Berlim, Checkpoint Charlie e mais.
- **Berlim Alternativa** – Arte urbana, Kreuzberg, vida noturna.
- **Tour Histórico** – Segunda Guerra, Guerra Fria, Nazismo e Reunificação.
- **Personalizado** – Sob medida para seu interesse.

Entre em contato e montamos o roteiro ideal para sua viagem!
